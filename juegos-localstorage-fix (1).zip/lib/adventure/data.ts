import type {
  Activity,
  Badge,
  Course,
  Grade,
  Question,
  Student,
  StudentAnalysis,
  Subject,
  SubjectProgress,
  Teacher,
} from './types'

export const badges: Badge[] = [
  { id: 'b-first', name: 'Primer paso', description: 'Completaste tu primera actividad', emoji: '🌱' },
  { id: 'b-streak3', name: 'En racha', description: '3 días seguidos aprendiendo', emoji: '🔥' },
  { id: 'b-streak7', name: 'Imparable', description: '7 días seguidos', emoji: '⚡' },
  { id: 'b-perfect', name: 'Perfección', description: '100% de aciertos en una actividad', emoji: '🎯' },
  { id: 'b-words50', name: 'Vocabulario', description: 'Aprendiste 50 palabras nuevas', emoji: '📚' },
  { id: 'b-speed', name: 'Veloz', description: 'Ganaste un quiz contra reloj', emoji: '⏱️' },
  { id: 'b-level5', name: 'Explorador', description: 'Alcanzaste el nivel 5', emoji: '🧭' },
  { id: 'b-champion', name: 'Campeón de la clase', description: '#1 en el ranking semanal', emoji: '👑' },
]

export const courses: Course[] = [
  { id: 'c-4a', name: 'Primaria', grade: 'Primaria', teacherId: 't-1', color: 'primary' },
]

export const subjects: Subject[] = [
  { id: 's-english', name: 'Inglés', emoji: '🇬🇧', courseId: 'c-4a' },
]

export const teachers: Teacher[] = [
  {
    id: 't-1',
    name: 'Miss Laura',
    username: 'laura',
    role: 'profesor',
    avatar: '/avatars/teacher.png',
    courseIds: ['c-4a'],
    grade: '4',
  },
]

export const students: Student[] = [
  {
    id: 'st-1',
    name: 'Sofía Martínez',
    username: 'sofia',
    role: 'alumno',
    avatar: '/avatars/sofia.png',
    courseId: 'c-4a',
    grade: '4',
    level: 6,
    xp: 1580,
    streakDays: 5,
    badgeIds: ['b-first', 'b-streak3', 'b-perfect', 'b-words50', 'b-level5'],
  },
  {
    id: 'st-2',
    name: 'Mateo Gómez',
    username: 'mateo',
    role: 'alumno',
    avatar: '/avatars/mateo.png',
    courseId: 'c-4a',
    grade: '4',
    level: 7,
    xp: 1920,
    streakDays: 8,
    badgeIds: ['b-first', 'b-streak7', 'b-speed', 'b-level5'],
  },
  {
    id: 'st-3',
    name: 'Valentina Ruiz',
    username: 'valentina',
    role: 'alumno',
    avatar: '/avatars/valentina.png',
    courseId: 'c-4a',
    grade: '4',
    level: 8,
    xp: 2350,
    streakDays: 12,
    badgeIds: ['b-first', 'b-streak7', 'b-perfect', 'b-champion', 'b-level5'],
  },
  {
    id: 'st-4',
    name: 'Thiago Díaz',
    username: 'thiago',
    role: 'alumno',
    avatar: '/avatars/thiago.png',
    courseId: 'c-4a',
    grade: '4',
    level: 4,
    xp: 980,
    streakDays: 2,
    badgeIds: ['b-first', 'b-streak3'],
  },
  {
    id: 'st-5',
    name: 'Emma López',
    username: 'emma',
    role: 'alumno',
    avatar: '/avatars/emma.png',
    courseId: 'c-4a',
    grade: '4',
    level: 3,
    xp: 720,
    streakDays: 1,
    badgeIds: ['b-first'],
  },
]

export const subjectProgress: Record<string, SubjectProgress[]> = {
  'st-1': [
    {
      subjectId: 's-english',
      progressPct: 68,
      level: 6,
      activitiesTotal: 9,
      activitiesCompleted: 6,
      xpEarned: 1580,
    },
  ],
}

// --- Juegos por nivel (1.º–2.º, 3.º–4.º y 5.º–6.º) ---
// Reglas para que ningún juego regale la respuesta:
//  - el enunciado nunca contiene la respuesta (las pistas se muestran SOLO después de contestar);
//  - las imágenes de las opciones no llevan texto (el nombre aparece al responder);
//  - las opciones se mezclan al jugar (ver prepareQuestion en game-player.tsx).
const IMG = '/games/ref/'

const FAMILY = ['mum', 'dad', 'grandma', 'grandpa', 'sister', 'brother', 'auntie']
function familyQuestion(id: string, target: string, others: string[]): Question {
  const names = [target, ...others]
  return {
    id,
    prompt: `Listen and tap: ${target}`,
    speak: target,
    options: names,
    optionImages: names.map((n) => `${IMG}family-${n}.png`),
    answerIndex: 0,
  }
}

const BODY_PARTS = ['head', 'arm', 'hand', 'body', 'leg', 'foot']
function bodyQuestion(id: string, part: string): Question {
  return {
    id,
    prompt: `Tap the ${part}.`,
    speak: part,
    options: BODY_PARTS,
    answerIndex: BODY_PARTS.indexOf(part),
    bodyPart: true,
    keepOrder: true,
  }
}

function sizeQuestion(id: string, item: string, ask: 'big' | 'small'): Question {
  return {
    id,
    prompt: ask === 'big' ? 'Tap the BIG one.' : 'Tap the SMALL one.',
    speak: ask,
    options: ['big', 'small'],
    optionImages: [`${IMG}${item}-big.png`, `${IMG}${item}-small.png`],
    answerIndex: ask === 'big' ? 0 : 1,
  }
}

function lengthQuestion(id: string, item: string, ask: 'short' | 'long'): Question {
  return {
    id,
    prompt: ask === 'long' ? `Which ${item} is LONG?` : `Which ${item} is SHORT?`,
    speak: ask,
    options: ['short', 'long'],
    optionImages: [`${IMG}short-${item}.svg`, `${IMG}long-${item}.svg`],
    optionLayout: 'stack',
    answerIndex: ask === 'long' ? 1 : 0,
  }
}

const FOOD = ['apple', 'burger', 'broccoli', 'fries', 'ice cream', 'fish']
const FOOD_IMG: Record<string, string> = {
  apple: `${IMG}food-apple.png`,
  burger: `${IMG}food-burger.png`,
  broccoli: `${IMG}food-broccoli.png`,
  fries: `${IMG}food-fries.png`,
  'ice cream': `${IMG}food-icecream.png`,
  fish: `${IMG}food-fish.png`,
}
function foodQuestion(id: string, prompt: string, options: string[], correct: string[], hint?: string): Question {
  const multi = correct.length > 1
  return {
    id,
    prompt,
    options,
    optionImages: options.map((o) => FOOD_IMG[o]),
    ...(multi
      ? { answerIndexes: correct.map((c) => options.indexOf(c)) }
      : { answerIndex: options.indexOf(correct[0]) }),
    hint,
  }
}

const ANIMAL_IMG: Record<string, string> = {
  dog: `${IMG}animal-dog.png`,
  cat: `${IMG}animal-cat.png`,
  rabbit: `${IMG}animal-rabbit.png`,
  bird: `${IMG}animal-bird.png`,
}
function animalChoice(id: string, prompt: string, options: string[], correct: string, speak?: string): Question {
  return {
    id,
    prompt,
    speak,
    options,
    optionImages: options.map((o) => ANIMAL_IMG[o]),
    answerIndex: options.indexOf(correct),
  }
}

const CAN_OPTIONS = ['can', 'can’t']
function canQuestion(id: string, image: string, prompt: string, can: boolean): Question {
  return { id, prompt, image, options: CAN_OPTIONS, answerIndex: can ? 0 : 1, keepOrder: true }
}

const EMMA_TEXT =
  'Emma is eating healthy food.\nShe can eat fruit and vegetables.\nShe can’t eat chips and sweets.'

const referenceGames: Record<'early' | 'middle' | 'upper', Activity[]> = {
  // 1.º–2.º
  early: [
    {
      id: 'g-family',
      title: 'Family',
      description: 'Listen and choose the correct family member.',
      type: 'image-question',
      difficulty: 'facil',
      subjectId: 's-english',
      grade: '1',
      xpReward: 10,
      questions: [
        familyQuestion('q1', 'mum', ['dad', 'grandpa', 'brother']),
        familyQuestion('q2', 'dad', ['grandma', 'sister', 'grandpa']),
        familyQuestion('q3', 'grandma', ['dad', 'brother', 'grandpa']),
        familyQuestion('q4', 'brother', ['mum', 'grandma', 'grandpa']),
        familyQuestion('q5', 'sister', ['dad', 'grandma', 'brother']),
        familyQuestion('q6', 'auntie', ['dad', 'grandpa', 'brother']),
      ],
    },
    {
      id: 'g-body',
      title: 'Parts of the body',
      description: 'Tap the correct part of the body.',
      type: 'image-question',
      difficulty: 'facil',
      subjectId: 's-english',
      grade: '1',
      xpReward: 10,
      questions: [
        bodyQuestion('q1', 'head'),
        bodyQuestion('q2', 'hand'),
        bodyQuestion('q3', 'leg'),
        bodyQuestion('q4', 'arm'),
        bodyQuestion('q5', 'foot'),
        bodyQuestion('q6', 'body'),
      ],
    },
    {
      id: 'g-bigsmall',
      title: 'Big or small',
      description: 'Choose the big or small one.',
      type: 'image-question',
      difficulty: 'facil',
      subjectId: 's-english',
      grade: '1',
      xpReward: 10,
      questions: [
        sizeQuestion('q1', 'elephant', 'big'),
        sizeQuestion('q2', 'car', 'small'),
        sizeQuestion('q3', 'apple', 'big'),
        sizeQuestion('q4', 'cat', 'small'),
      ],
    },
  ],
  // 3.º–4.º
  middle: [
    {
      id: 'g-shortlong',
      title: 'Short or long',
      description: 'Look at the pictures and choose: short or long.',
      type: 'image-question',
      difficulty: 'medio',
      subjectId: 's-english',
      grade: '3',
      xpReward: 15,
      questions: [
        lengthQuestion('q1', 'pencil', 'long'),
        lengthQuestion('q2', 'train', 'short'),
        lengthQuestion('q3', 'scarf', 'long'),
        lengthQuestion('q4', 'pencil', 'short'),
      ],
    },
    {
      id: 'g-food',
      title: 'Food',
      description: 'Choose the healthy food.',
      type: 'image-question',
      difficulty: 'medio',
      subjectId: 's-english',
      grade: '3',
      xpReward: 15,
      questions: [
        foodQuestion('q1', 'Choose the healthy food.', FOOD, ['apple', 'broccoli', 'fish'], 'Fruit, vegetables and fish are healthy food.'),
        foodQuestion('q2', 'Which one is a fruit?', ['apple', 'burger', 'fries', 'fish'], ['apple']),
        foodQuestion('q3', 'Which one is a vegetable?', ['ice cream', 'broccoli', 'burger', 'fries'], ['broccoli']),
        foodQuestion('q4', 'Choose the food that is NOT healthy.', FOOD, ['burger', 'fries', 'ice cream'], 'Burgers, chips and sweets are not so healthy.'),
      ],
    },
    {
      id: 'g-animals',
      title: 'Animals (pets)',
      description: 'Match the animal with the correct name.',
      type: 'match-concepts',
      difficulty: 'medio',
      subjectId: 's-english',
      grade: '3',
      xpReward: 15,
      questions: [
        {
          id: 'q1',
          prompt: 'Match the animal with the correct name.',
          pairs: [
            { left: 'dog', right: 'dog', leftImage: ANIMAL_IMG.dog },
            { left: 'cat', right: 'cat', leftImage: ANIMAL_IMG.cat },
            { left: 'rabbit', right: 'rabbit', leftImage: ANIMAL_IMG.rabbit },
            { left: 'bird', right: 'bird', leftImage: ANIMAL_IMG.bird },
          ],
        },
        animalChoice('q2', 'Which animal can fly?', ['dog', 'bird', 'cat', 'rabbit'], 'bird'),
        animalChoice('q3', 'Which animal says “meow”?', ['dog', 'rabbit', 'cat', 'bird'], 'cat'),
        animalChoice('q4', 'Listen and tap the animal.', ['cat', 'rabbit', 'dog', 'bird'], 'rabbit', 'rabbit'),
      ],
    },
  ],
  // 5.º–6.º
  upper: [
    {
      id: 'g-cancant',
      title: 'Can / can’t',
      description: 'Look at the pictures and choose can or can’t.',
      type: 'multiple-choice',
      difficulty: 'dificil',
      subjectId: 's-english',
      grade: '5',
      xpReward: 20,
      questions: [
        canQuestion('q1', `${IMG}can-bike.png`, 'Look at the picture: She ___ ride a bike.', true),
        canQuestion('q2', `${IMG}can-swim.png`, 'Look at the picture: He ___ swim.', true),
        canQuestion('q3', ANIMAL_IMG.bird, 'Look at the picture: A bird ___ fly.', true),
        canQuestion('q4', `${IMG}elephant-big.png`, 'Look at the picture: An elephant ___ fly.', false),
        canQuestion('q5', ANIMAL_IMG.cat, 'Look at the picture: A cat ___ drive a car.', false),
      ],
    },
    {
      id: 'g-extra',
      title: 'Extra challenge',
      description: 'Read and choose the correct answer.',
      type: 'multiple-choice',
      difficulty: 'dificil',
      subjectId: 's-english',
      grade: '5',
      xpReward: 25,
      questions: [
        {
          id: 'q1',
          prompt: 'What is she eating?',
          image: `${IMG}emma.png`,
          passage: EMMA_TEXT,
          options: ['A burger', 'Salad', 'Pizza', 'Ice cream'],
          answerIndex: 1,
          hint: 'Emma can eat fruit and vegetables.',
        },
        {
          id: 'q2',
          prompt: 'What can Emma eat?',
          passage: EMMA_TEXT,
          options: ['Chips and sweets', 'Fruit and vegetables', 'Burgers and pizza', 'Only ice cream'],
          answerIndex: 1,
        },
        {
          id: 'q3',
          prompt: 'What can’t Emma eat?',
          passage: EMMA_TEXT,
          options: ['Fruit', 'Vegetables', 'Chips and sweets', 'Salad'],
          answerIndex: 2,
        },
      ],
    },
  ],
}

export const activities: Activity[] = [
  {
    id: 'a-1',
    title: 'Animales / Animals',
    description: 'Aprende los nombres de los animales en inglés.',
    type: 'multiple-choice',
    difficulty: 'facil',
    subjectId: 's-english',
    grade: '4',
    xpReward: 60,
    questions: [
      {
        id: 'q1',
        prompt: '¿Cómo se dice "perro" en inglés?',
        hint: 'Es la mascota más común',
        options: ['Cat', 'Dog', 'Bird', 'Fish'],
        answerIndex: 1,
      },
      {
        id: 'q2',
        prompt: '¿Cómo se dice "gato"?',
        options: ['Dog', 'Horse', 'Cat', 'Cow'],
        answerIndex: 2,
      },
      {
        id: 'q3',
        prompt: 'Elige la traducción de "pájaro"',
        options: ['Bird', 'Bear', 'Bee', 'Bat'],
        answerIndex: 0,
      },
    ],
  },
  {
    id: 'a-2',
    title: 'Colores / Colors',
    description: '¿Verdadero o falso? Repasa los colores.',
    type: 'true-false',
    difficulty: 'facil',
    subjectId: 's-english',
    grade: '4',
    xpReward: 50,
    questions: [
      { id: 'q1', prompt: '"Red" significa rojo', options: ['Verdadero', 'Falso'], answerIndex: 0 },
      { id: 'q2', prompt: '"Blue" significa verde', options: ['Verdadero', 'Falso'], answerIndex: 1 },
      { id: 'q3', prompt: '"Yellow" significa amarillo', options: ['Verdadero', 'Falso'], answerIndex: 0 },
      { id: 'q4', prompt: '"Black" significa blanco', options: ['Verdadero', 'Falso'], answerIndex: 1 },
    ],
  },
  {
    id: 'a-3',
    title: 'Completa la palabra',
    description: 'Escribe la palabra en inglés que falta.',
    type: 'complete-word',
    difficulty: 'medio',
    subjectId: 's-english',
    grade: '4',
    xpReward: 80,
    questions: [
      { id: 'q1', prompt: 'Casa en inglés: h___', hint: 'house', answer: 'house' },
      { id: 'q2', prompt: 'Escuela en inglés: s_____', hint: 'school', answer: 'school' },
      { id: 'q3', prompt: 'Libro en inglés: b___', hint: 'book', answer: 'book' },
    ],
  },
  {
    id: 'a-4',
    title: 'Une los conceptos',
    description: 'Conecta cada palabra con su traducción.',
    type: 'match-concepts',
    difficulty: 'medio',
    subjectId: 's-english',
    grade: '4',
    xpReward: 90,
    questions: [
      {
        id: 'q1',
        prompt: 'Une cada palabra en inglés con su significado',
        pairs: [
          { left: 'Apple', right: 'Manzana' },
          { left: 'Water', right: 'Agua' },
          { left: 'Sun', right: 'Sol' },
          { left: 'Friend', right: 'Amigo' },
        ],
      },
    ],
  },
  {
    id: 'a-5',
    title: 'Ordena la oración',
    description: 'Coloca las palabras en el orden correcto.',
    type: 'order-elements',
    difficulty: 'dificil',
    subjectId: 's-english',
    grade: '4',
    xpReward: 100,
    questions: [
      { id: 'q1', prompt: 'Ordena: "Me llamo Ana"', sequence: ['My', 'name', 'is', 'Ana'] },
      { id: 'q2', prompt: 'Ordena: "Tengo un gato"', sequence: ['I', 'have', 'a', 'cat'] },
    ],
  },
  {
    id: 'a-6',
    title: 'Adivina la imagen',
    description: 'Mira la imagen y elige la palabra correcta.',
    type: 'image-question',
    difficulty: 'facil',
    subjectId: 's-english',
    grade: '4',
    xpReward: 70,
    questions: [
      {
        id: 'q1',
        prompt: '¿Qué es esto en inglés?',
        image: '/games/apple.png',
        options: ['Apple', 'Orange', 'Banana', 'Grape'],
        answerIndex: 0,
      },
      {
        id: 'q2',
        prompt: '¿Qué animal es?',
        image: '/games/cat.png',
        options: ['Dog', 'Cat', 'Rabbit', 'Mouse'],
        answerIndex: 1,
      },
    ],
  },
  {
    id: 'a-7',
    title: 'Juego de memoria',
    description: 'Encuentra las parejas palabra–traducción.',
    type: 'memory',
    difficulty: 'medio',
    subjectId: 's-english',
    grade: '4',
    xpReward: 85,
    questions: [
      {
        id: 'q1',
        prompt: 'Encuentra las parejas',
        pairs: [
          { left: 'Cat', right: 'Gato' },
          { left: 'Dog', right: 'Perro' },
          { left: 'Sun', right: 'Sol' },
          { left: 'Book', right: 'Libro' },
        ],
      },
    ],
  },
  {
    id: 'a-8',
    title: 'Quiz contra reloj',
    description: 'Responde todo lo que puedas antes de que acabe el tiempo.',
    type: 'timed-quiz',
    difficulty: 'dificil',
    subjectId: 's-english',
    grade: '4',
    xpReward: 120,
    timeLimitSec: 45,
    questions: [
      { id: 'q1', prompt: '"One" es...', options: ['Uno', 'Dos', 'Tres'], answerIndex: 0 },
      { id: 'q2', prompt: '"Three" es...', options: ['Dos', 'Tres', 'Cuatro'], answerIndex: 1 },
      { id: 'q3', prompt: '"Five" es...', options: ['Cinco', 'Seis', 'Siete'], answerIndex: 0 },
      { id: 'q4', prompt: '"Ten" es...', options: ['Nueve', 'Diez', 'Once'], answerIndex: 1 },
      { id: 'q5', prompt: '"Seven" es...', options: ['Siete', 'Ocho', 'Seis'], answerIndex: 0 },
    ],
  },
]

// --- Datos de análisis para el portal del profesor ---
// Simulados para demostrar la vista de análisis detallado por alumno.

function statusForPct(pct: number): 'dominado' | 'en-progreso' | 'necesita-refuerzo' {
  if (pct >= 80) return 'dominado'
  if (pct >= 60) return 'en-progreso'
  return 'necesita-refuerzo'
}

export const studentAnalyses: Record<string, StudentAnalysis> = {
  'st-1': {
    studentId: 'st-1',
    xp: 1580,
    level: 6,
    streakDays: 5,
    overallProgressPct: 68,
    activitiesCompleted: 6,
    activitiesPending: 3,
    correctPct: 78,
    incorrectPct: 22,
    totalAttempts: 14,
    avgTimeSec: 52,
    performance: [
      { date: 'Sem 1', score: 55 },
      { date: 'Sem 2', score: 62 },
      { date: 'Sem 3', score: 70 },
      { date: 'Sem 4', score: 68 },
      { date: 'Sem 5', score: 78 },
    ],
    skills: [
      { skill: 'Vocabulary', pct: 85, status: 'dominado' },
      { skill: 'Grammar', pct: 58, status: 'en-progreso' },
      { skill: 'Reading', pct: 72, status: 'en-progreso' },
      { skill: 'Listening', pct: 80, status: 'dominado' },
      { skill: 'Writing', pct: 54, status: 'necesita-refuerzo' },
    ],
    topics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 52, status: 'necesita-refuerzo' },
      { topic: 'Verb to be', skill: 'Grammar', pct: 86, status: 'dominado' },
      { topic: 'Have got', skill: 'Grammar', pct: 68, status: 'en-progreso' },
      { topic: 'Animals', skill: 'Vocabulary', pct: 90, status: 'dominado' },
      { topic: 'Colors', skill: 'Vocabulary', pct: 82, status: 'dominado' },
      { topic: 'Numbers', skill: 'Vocabulary', pct: 78, status: 'en-progreso' },
      { topic: 'Short texts', skill: 'Reading', pct: 72, status: 'en-progreso' },
      { topic: 'Instructions', skill: 'Listening', pct: 80, status: 'dominado' },
      { topic: 'Short sentences', skill: 'Writing', pct: 54, status: 'necesita-refuerzo' },
    ],
    recentActivities: [
      { activityId: 'a-1', title: 'Animales / Animals', score: 100, correctCount: 3, totalCount: 3, timeSec: 35, date: '2026-09-24', status: 'completada' },
      { activityId: 'a-2', title: 'Colores / Colors', score: 75, correctCount: 3, totalCount: 4, timeSec: 40, date: '2026-09-22', status: 'completada' },
      { activityId: 'a-3', title: 'Completa la palabra', score: 67, correctCount: 2, totalCount: 3, timeSec: 68, date: '2026-09-20', status: 'completada' },
      { activityId: 'a-4', title: 'Une los conceptos', score: 75, correctCount: 3, totalCount: 4, timeSec: 55, date: '2026-09-18', status: 'completada' },
      { activityId: 'a-5', title: 'Ordena la oración', score: 50, correctCount: 1, totalCount: 2, timeSec: 72, date: '2026-09-15', status: 'completada' },
      { activityId: 'a-6', title: 'Adivina la imagen', score: 100, correctCount: 2, totalCount: 2, timeSec: 30, date: '2026-09-12', status: 'completada' },
      { activityId: 'a-7', title: 'Juego de memoria', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-8', title: 'Quiz contra reloj', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
    ],
    weakTopics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 52, status: 'necesita-refuerzo' },
      { topic: 'Short sentences', skill: 'Writing', pct: 54, status: 'necesita-refuerzo' },
      { topic: 'Have got', skill: 'Grammar', pct: 68, status: 'en-progreso' },
    ],
    recommendation:
      'Sofía tiene buen vocabulario y comprensión auditiva. Conviene reforzar Present Simple y escritura de oraciones cortas con ejercicios prácticos guiados.',
  },
  'st-2': {
    studentId: 'st-2',
    xp: 1920,
    level: 7,
    streakDays: 8,
    overallProgressPct: 75,
    activitiesCompleted: 7,
    activitiesPending: 2,
    correctPct: 83,
    incorrectPct: 17,
    totalAttempts: 16,
    avgTimeSec: 44,
    performance: [
      { date: 'Sem 1', score: 68 },
      { date: 'Sem 2', score: 74 },
      { date: 'Sem 3', score: 78 },
      { date: 'Sem 4', score: 82 },
      { date: 'Sem 5', score: 85 },
    ],
    skills: [
      { skill: 'Vocabulary', pct: 88, status: 'dominado' },
      { skill: 'Grammar', pct: 72, status: 'en-progreso' },
      { skill: 'Reading', pct: 80, status: 'dominado' },
      { skill: 'Listening', pct: 75, status: 'en-progreso' },
      { skill: 'Writing', pct: 68, status: 'en-progreso' },
    ],
    topics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 72, status: 'en-progreso' },
      { topic: 'Verb to be', skill: 'Grammar', pct: 90, status: 'dominado' },
      { topic: 'Have got', skill: 'Grammar', pct: 75, status: 'en-progreso' },
      { topic: 'Animals', skill: 'Vocabulary', pct: 92, status: 'dominado' },
      { topic: 'Colors', skill: 'Vocabulary', pct: 88, status: 'dominado' },
      { topic: 'Numbers', skill: 'Vocabulary', pct: 85, status: 'dominado' },
      { topic: 'Short texts', skill: 'Reading', pct: 80, status: 'dominado' },
      { topic: 'Instructions', skill: 'Listening', pct: 75, status: 'en-progreso' },
      { topic: 'Short sentences', skill: 'Writing', pct: 68, status: 'en-progreso' },
    ],
    recentActivities: [
      { activityId: 'a-1', title: 'Animales / Animals', score: 100, correctCount: 3, totalCount: 3, timeSec: 28, date: '2026-09-24', status: 'completada' },
      { activityId: 'a-2', title: 'Colores / Colors', score: 100, correctCount: 4, totalCount: 4, timeSec: 32, date: '2026-09-23', status: 'completada' },
      { activityId: 'a-3', title: 'Completa la palabra', score: 100, correctCount: 3, totalCount: 3, timeSec: 45, date: '2026-09-21', status: 'completada' },
      { activityId: 'a-4', title: 'Une los conceptos', score: 100, correctCount: 4, totalCount: 4, timeSec: 50, date: '2026-09-19', status: 'completada' },
      { activityId: 'a-5', title: 'Ordena la oración', score: 50, correctCount: 1, totalCount: 2, timeSec: 60, date: '2026-09-17', status: 'completada' },
      { activityId: 'a-6', title: 'Adivina la imagen', score: 100, correctCount: 2, totalCount: 2, timeSec: 25, date: '2026-09-14', status: 'completada' },
      { activityId: 'a-7', title: 'Juego de memoria', score: 75, correctCount: 3, totalCount: 4, timeSec: 48, date: '2026-09-10', status: 'completada' },
      { activityId: 'a-8', title: 'Quiz contra reloj', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
    ],
    weakTopics: [
      { topic: 'Short sentences', skill: 'Writing', pct: 68, status: 'en-progreso' },
      { topic: 'Instructions', skill: 'Listening', pct: 75, status: 'en-progreso' },
      { topic: 'Present Simple', skill: 'Grammar', pct: 72, status: 'en-progreso' },
    ],
    recommendation:
      'Mateo va muy bien en vocabulario y lectura. Para llegar al dominio total, conviene practicar escritura de oraciones cortas y comprensión auditiva con audios más variados.',
  },
  'st-3': {
    studentId: 'st-3',
    xp: 2350,
    level: 8,
    streakDays: 12,
    overallProgressPct: 88,
    activitiesCompleted: 8,
    activitiesPending: 1,
    correctPct: 92,
    incorrectPct: 8,
    totalAttempts: 20,
    avgTimeSec: 38,
    performance: [
      { date: 'Sem 1', score: 80 },
      { date: 'Sem 2', score: 85 },
      { date: 'Sem 3', score: 88 },
      { date: 'Sem 4', score: 90 },
      { date: 'Sem 5', score: 92 },
    ],
    skills: [
      { skill: 'Vocabulary', pct: 95, status: 'dominado' },
      { skill: 'Grammar', pct: 88, status: 'dominado' },
      { skill: 'Reading', pct: 90, status: 'dominado' },
      { skill: 'Listening', pct: 85, status: 'dominado' },
      { skill: 'Writing', pct: 82, status: 'dominado' },
    ],
    topics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 88, status: 'dominado' },
      { topic: 'Verb to be', skill: 'Grammar', pct: 96, status: 'dominado' },
      { topic: 'Have got', skill: 'Grammar', pct: 90, status: 'dominado' },
      { topic: 'Animals', skill: 'Vocabulary', pct: 98, status: 'dominado' },
      { topic: 'Colors', skill: 'Vocabulary', pct: 95, status: 'dominado' },
      { topic: 'Numbers', skill: 'Vocabulary', pct: 92, status: 'dominado' },
      { topic: 'Short texts', skill: 'Reading', pct: 90, status: 'dominado' },
      { topic: 'Instructions', skill: 'Listening', pct: 85, status: 'dominado' },
      { topic: 'Short sentences', skill: 'Writing', pct: 82, status: 'dominado' },
    ],
    recentActivities: [
      { activityId: 'a-1', title: 'Animales / Animals', score: 100, correctCount: 3, totalCount: 3, timeSec: 22, date: '2026-09-24', status: 'completada' },
      { activityId: 'a-2', title: 'Colores / Colors', score: 100, correctCount: 4, totalCount: 4, timeSec: 25, date: '2026-09-23', status: 'completada' },
      { activityId: 'a-3', title: 'Completa la palabra', score: 100, correctCount: 3, totalCount: 3, timeSec: 35, date: '2026-09-21', status: 'completada' },
      { activityId: 'a-4', title: 'Une los conceptos', score: 100, correctCount: 4, totalCount: 4, timeSec: 40, date: '2026-09-19', status: 'completada' },
      { activityId: 'a-5', title: 'Ordena la oración', score: 100, correctCount: 2, totalCount: 2, timeSec: 45, date: '2026-09-17', status: 'completada' },
      { activityId: 'a-6', title: 'Adivina la imagen', score: 100, correctCount: 2, totalCount: 2, timeSec: 20, date: '2026-09-14', status: 'completada' },
      { activityId: 'a-7', title: 'Juego de memoria', score: 100, correctCount: 4, totalCount: 4, timeSec: 38, date: '2026-09-10', status: 'completada' },
      { activityId: 'a-8', title: 'Quiz contra reloj', score: 80, correctCount: 4, totalCount: 5, timeSec: 38, date: '2026-09-07', status: 'completada' },
    ],
    weakTopics: [
      { topic: 'Short sentences', skill: 'Writing', pct: 82, status: 'dominado' },
      { topic: 'Instructions', skill: 'Listening', pct: 85, status: 'dominado' },
      { topic: 'Present Simple', skill: 'Grammar', pct: 88, status: 'dominado' },
    ],
    recommendation:
      'Valentina domina todas las habilidades. Se sugieren actividades de desafío avanzado y escritura libre para mantenerla motivada.',
  },
  'st-4': {
    studentId: 'st-4',
    xp: 980,
    level: 4,
    streakDays: 2,
    overallProgressPct: 42,
    activitiesCompleted: 4,
    activitiesPending: 5,
    correctPct: 55,
    incorrectPct: 45,
    totalAttempts: 9,
    avgTimeSec: 68,
    performance: [
      { date: 'Sem 1', score: 40 },
      { date: 'Sem 2', score: 45 },
      { date: 'Sem 3', score: 52 },
      { date: 'Sem 4', score: 50 },
      { date: 'Sem 5', score: 55 },
    ],
    skills: [
      { skill: 'Vocabulary', pct: 62, status: 'en-progreso' },
      { skill: 'Grammar', pct: 42, status: 'necesita-refuerzo' },
      { skill: 'Reading', pct: 55, status: 'necesita-refuerzo' },
      { skill: 'Listening', pct: 58, status: 'necesita-refuerzo' },
      { skill: 'Writing', pct: 40, status: 'necesita-refuerzo' },
    ],
    topics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 38, status: 'necesita-refuerzo' },
      { topic: 'Verb to be', skill: 'Grammar', pct: 55, status: 'necesita-refuerzo' },
      { topic: 'Have got', skill: 'Grammar', pct: 42, status: 'necesita-refuerzo' },
      { topic: 'Animals', skill: 'Vocabulary', pct: 70, status: 'en-progreso' },
      { topic: 'Colors', skill: 'Vocabulary', pct: 60, status: 'en-progreso' },
      { topic: 'Numbers', skill: 'Vocabulary', pct: 55, status: 'necesita-refuerzo' },
      { topic: 'Short texts', skill: 'Reading', pct: 55, status: 'necesita-refuerzo' },
      { topic: 'Instructions', skill: 'Listening', pct: 58, status: 'necesita-refuerzo' },
      { topic: 'Short sentences', skill: 'Writing', pct: 40, status: 'necesita-refuerzo' },
    ],
    recentActivities: [
      { activityId: 'a-1', title: 'Animales / Animals', score: 67, correctCount: 2, totalCount: 3, timeSec: 55, date: '2026-09-22', status: 'completada' },
      { activityId: 'a-2', title: 'Colores / Colors', score: 50, correctCount: 2, totalCount: 4, timeSec: 60, date: '2026-09-20', status: 'completada' },
      { activityId: 'a-3', title: 'Completa la palabra', score: 33, correctCount: 1, totalCount: 3, timeSec: 80, date: '2026-09-18', status: 'completada' },
      { activityId: 'a-6', title: 'Adivina la imagen', score: 100, correctCount: 2, totalCount: 2, timeSec: 40, date: '2026-09-15', status: 'completada' },
      { activityId: 'a-4', title: 'Une los conceptos', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-5', title: 'Ordena la oración', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-7', title: 'Juego de memoria', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-8', title: 'Quiz contra reloj', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
    ],
    weakTopics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 38, status: 'necesita-refuerzo' },
      { topic: 'Short sentences', skill: 'Writing', pct: 40, status: 'necesita-refuerzo' },
      { topic: 'Have got', skill: 'Grammar', pct: 42, status: 'necesita-refuerzo' },
    ],
    recommendation:
      'Thiago necesita refuerzo general. Se sugiere empezar con actividades de vocabulario visual (animales, colores) y luego introducir Present Simple con ejercicios muy guiados.',
  },
  'st-5': {
    studentId: 'st-5',
    xp: 720,
    level: 3,
    streakDays: 1,
    overallProgressPct: 28,
    activitiesCompleted: 3,
    activitiesPending: 6,
    correctPct: 48,
    incorrectPct: 52,
    totalAttempts: 6,
    avgTimeSec: 75,
    performance: [
      { date: 'Sem 1', score: 30 },
      { date: 'Sem 2', score: 35 },
      { date: 'Sem 3', score: 42 },
      { date: 'Sem 4', score: 45 },
      { date: 'Sem 5', score: 48 },
    ],
    skills: [
      { skill: 'Vocabulary', pct: 52, status: 'necesita-refuerzo' },
      { skill: 'Grammar', pct: 35, status: 'necesita-refuerzo' },
      { skill: 'Reading', pct: 45, status: 'necesita-refuerzo' },
      { skill: 'Listening', pct: 50, status: 'necesita-refuerzo' },
      { skill: 'Writing', pct: 30, status: 'necesita-refuerzo' },
    ],
    topics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 30, status: 'necesita-refuerzo' },
      { topic: 'Verb to be', skill: 'Grammar', pct: 45, status: 'necesita-refuerzo' },
      { topic: 'Have got', skill: 'Grammar', pct: 38, status: 'necesita-refuerzo' },
      { topic: 'Animals', skill: 'Vocabulary', pct: 60, status: 'en-progreso' },
      { topic: 'Colors', skill: 'Vocabulary', pct: 50, status: 'necesita-refuerzo' },
      { topic: 'Numbers', skill: 'Vocabulary', pct: 45, status: 'necesita-refuerzo' },
      { topic: 'Short texts', skill: 'Reading', pct: 45, status: 'necesita-refuerzo' },
      { topic: 'Instructions', skill: 'Listening', pct: 50, status: 'necesita-refuerzo' },
      { topic: 'Short sentences', skill: 'Writing', pct: 30, status: 'necesita-refuerzo' },
    ],
    recentActivities: [
      { activityId: 'a-1', title: 'Animales / Animals', score: 67, correctCount: 2, totalCount: 3, timeSec: 60, date: '2026-09-21', status: 'completada' },
      { activityId: 'a-2', title: 'Colores / Colors', score: 50, correctCount: 2, totalCount: 4, timeSec: 70, date: '2026-09-19', status: 'completada' },
      { activityId: 'a-6', title: 'Adivina la imagen', score: 50, correctCount: 1, totalCount: 2, timeSec: 45, date: '2026-09-16', status: 'completada' },
      { activityId: 'a-3', title: 'Completa la palabra', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-4', title: 'Une los conceptos', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-5', title: 'Ordena la oración', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-7', title: 'Juego de memoria', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
      { activityId: 'a-8', title: 'Quiz contra reloj', score: 0, correctCount: 0, totalCount: 0, timeSec: 0, date: '', status: 'pendiente' },
    ],
    weakTopics: [
      { topic: 'Present Simple', skill: 'Grammar', pct: 30, status: 'necesita-refuerzo' },
      { topic: 'Short sentences', skill: 'Writing', pct: 30, status: 'necesita-refuerzo' },
      { topic: 'Have got', skill: 'Grammar', pct: 38, status: 'necesita-refuerzo' },
    ],
    recommendation:
      'Emma está comenzando. Conviene priorizar actividades visuales de vocabulario (animales, colores) y reforzar "Verb to be" con ejercicios cortos antes de avanzar a escritura.',
  },
}

// Helpers de acceso (sustituibles por consultas reales a la base de datos).
export function getStudentByUsername(username: string): Student | undefined {
  const normalized = username.trim().toLowerCase()
  let stored: Student[] = []
  if (typeof window !== 'undefined') {
    try {
      const parsed = JSON.parse(localStorage.getItem('adventure-users') ?? '[]')
      if (Array.isArray(parsed)) stored = parsed as Student[]
    } catch {
      stored = []
    }
  }
  const allStudents = [...students, ...stored.filter((user) => !students.some((item) => item.id === user.id))]
  return allStudents.find((s) => s.username === normalized)
}

export function getTeacherByUsername(username: string): Teacher | undefined {
  return teachers.find((t) => t.username === username.toLowerCase())
}

export function getActivity(id: string): Activity | undefined {
  return activities.find((a) => a.id === id)
}

export function getActivitiesForSubject(subjectId: string): Activity[] {
  return activities.filter((a) => a.subjectId === subjectId)
}

export function getBadge(id: string): Badge | undefined {
  return badges.find((b) => b.id === id)
}

export function getCourseStudents(courseId: string): Student[] {
  return students
    .filter((s) => s.courseId === courseId)
    .sort((a, b) => b.xp - a.xp)
}

export function getStudent(id: string): Student | undefined {
  return students.find((s) => s.id === id)
}

export function getStudentAnalysis(id: string): StudentAnalysis | undefined {
  return studentAnalyses[id]
}

export const GRADE_LABELS: Record<Grade, string> = {
  '1': '1.º grado',
  '2': '2.º grado',
  '3': '3.º grado',
  '4': '4.º grado',
  '5': '5.º grado',
  '6': '6.º grado',
}

export const GRADE_OPTIONS: Grade[] = ['1', '2', '3', '4', '5', '6']

function legacyActivitiesForGrade(grade: Grade): Activity[] {
  const baseDifficulty = grade === '1' || grade === '2' ? 'facil' : grade === '4' ? 'medio' : 'dificil'
  const isEarlyGrade = grade === '1' || grade === '2'
  const isAdvancedGrade = grade === '5' || grade === '6'

  return activities
    .filter((activity) => !isEarlyGrade || activity.difficulty !== 'dificil')
    .map((activity) => ({
      ...activity,
      grade,
      difficulty: baseDifficulty,
      description: isEarlyGrade
        ? `${activity.description} Palabras cortas y apoyo visual.`
        : isAdvancedGrade
          ? `${activity.description} Incluye comprensión y razonamiento avanzado.`
          : activity.description,
      questions: isEarlyGrade
        ? activity.questions.slice(0, Math.max(1, Math.ceil(activity.questions.length / 2)))
        : activity.questions,
    }))
}

export function getActivitiesForGrade(grade: Grade): Activity[] {
  const band = grade === '1' || grade === '2' ? 'early' : grade === '3' || grade === '4' ? 'middle' : 'upper'
  const games = referenceGames[band].map((game) => ({ ...game, grade }))
  // Las actividades creadas por el profesor se mantienen visibles para todos los grados.
  const teacherMade = legacyActivitiesForGrade(grade).filter((a) => a.createdByTeacher)
  return [...games, ...teacherMade]
}

export function getActivityForGrade(id: string, grade: Grade): Activity | undefined {
  return (
    getActivitiesForGrade(grade).find((activity) => activity.id === id) ??
    // Enlaces antiguos (p. ej. el reto diario del panel) siguen funcionando.
    legacyActivitiesForGrade(grade).find((activity) => activity.id === id)
  )
}

export function addActivity(activity: Activity): void {
  activities.push(activity)
}
