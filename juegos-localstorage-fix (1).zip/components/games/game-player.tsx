'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { X, ArrowRight, Timer } from 'lucide-react'
import { cn } from '@/lib/utils'
import { ProgressBar } from '@/components/progress-bar'
import { useSession } from '@/components/session-provider'
import { ChoiceQuestion } from './choice-question'
import { CompleteWordQuestion } from './complete-word-question'
import { OrderQuestion } from './order-question'
import { MatchQuestion } from './match-question'
import { MemoryQuestion } from './memory-question'
import { BodyQuestion } from './body-question'
import { ActivityResultScreen } from './activity-result'
import { newlyEarnedBadges, scoreActivity } from '@/lib/adventure/gamification'
import { getTodayCompletion, recordCompletion } from '@/lib/adventure/progress'
import type { Activity, Question } from '@/lib/adventure/types'

function shuffleIndexes(n: number): number[] {
  const a = Array.from({ length: n }, (_, i) => i)
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

/**
 * Mezcla las opciones para que la respuesta correcta no esté siempre en la misma posición.
 * No mezcla verdadero/falso, can / can’t ni las partes del cuerpo (keepOrder / bodyPart).
 */
function prepareQuestion(activity: Activity, q: Question): Question {
  if (!q.options || q.options.length < 2) return q
  if (q.keepOrder || q.bodyPart || activity.type === 'true-false') return q
  const order = shuffleIndexes(q.options.length)
  return {
    ...q,
    options: order.map((i) => q.options![i]),
    optionImages: q.optionImages ? order.map((i) => q.optionImages![i]) : undefined,
    answerIndex: q.answerIndex !== undefined ? order.indexOf(q.answerIndex) : undefined,
    answerIndexes: q.answerIndexes ? q.answerIndexes.map((a) => order.indexOf(a)) : undefined,
  }
}

type Kind = 'choice' | 'body' | 'text' | 'order' | 'match' | 'memory'

function kindOf(activity: Activity, q: Question): Kind {
  if (q.pairs) return activity.type === 'memory' ? 'memory' : 'match'
  if (q.sequence) return 'order'
  if (q.answer !== undefined) return 'text'
  if (q.bodyPart) return 'body'
  return 'choice'
}

export function GamePlayer({ activity }: { activity: Activity }) {
  const router = useRouter()
  const { student, setStudent } = useSession()

  const [index, setIndex] = useState(0)
  const [correctCount, setCorrectCount] = useState(0)
  const [done, setDone] = useState(false)
  const [celebrate, setCelebrate] = useState(false)
  const [result, setResult] = useState<{ score: number; xpEarned: number; timeSec: number } | null>(null)
  const [newBadges, setNewBadges] = useState<string[]>([])
  const [todayCompleted] = useState(() => getTodayCompletion(student.id, activity.id))

  // Estado de la pregunta actual
  const [selected, setSelected] = useState<number | null>(null)
  const [selectedMulti, setSelectedMulti] = useState<number[]>([])
  const [textValue, setTextValue] = useState('')
  const [orderChosen, setOrderChosen] = useState<number[]>([])
  const [answered, setAnswered] = useState(false)
  const [lastCorrect, setLastCorrect] = useState(false)

  const startRef = useRef(Date.now())
  const finishedRef = useRef(false)
  const total = activity.questions.length
  const rawQuestion = activity.questions[index]
  // Las opciones se mezclan una sola vez por pregunta.
  const question = useMemo(() => prepareQuestion(activity, rawQuestion), [activity.id, index]) // eslint-disable-line react-hooks/exhaustive-deps
  const kind = kindOf(activity, question)
  const isMulti = kind === 'choice' && Array.isArray(question.answerIndexes)

  // Temporizador para quiz contra reloj
  const [timeLeft, setTimeLeft] = useState(activity.timeLimitSec ?? 0)
  const isTimed = activity.type === 'timed-quiz'

  useEffect(() => {
    if (!isTimed || done) return
    if (timeLeft <= 0) {
      finish(correctCount)
      return
    }
    const t = setTimeout(() => setTimeLeft((v) => v - 1), 1000)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeLeft, isTimed, done])

  function finish(finalCorrect: number) {
    if (finishedRef.current) return
    finishedRef.current = true
    const timeSec = Math.round((Date.now() - startRef.current) / 1000)
    const { score, xpEarned } = scoreActivity({
      correctCount: finalCorrect,
      totalCount: total,
      timeSec,
      timeLimitSec: activity.timeLimitSec,
      baseXpReward: activity.xpReward,
    })
    const rewardKey = `adventure-reward:${student.id}:${activity.id}`
    let alreadyRewarded = false
    try {
      alreadyRewarded = localStorage.getItem(rewardKey) === '1'
      if (!alreadyRewarded) localStorage.setItem(rewardKey, '1')
    } catch {
      alreadyRewarded = false
    }
    const awardedXp = alreadyRewarded ? 0 : xpEarned
    if (!alreadyRewarded && finalCorrect === total) setCelebrate(true)
    if (!alreadyRewarded) {
      recordCompletion({
        id: `${student.id}-${activity.id}-${Date.now()}`,
        studentId: student.id,
        activityId: activity.id,
        correctCount: finalCorrect,
        totalCount: total,
        timeSec,
        score,
        xpEarned: awardedXp,
        date: new Date().toISOString(),
      })
    }
    const updatedStudent = { ...student, xp: student.xp + awardedXp }
    const earnedNow = newlyEarnedBadges(updatedStudent, activity.id, score)
    if (earnedNow.length > 0) {
      updatedStudent.badgeIds = [...updatedStudent.badgeIds, ...earnedNow.map((badge) => badge.id)]
      setNewBadges(earnedNow.map((badge) => badge.name))
    }
    setStudent(updatedStudent)
    setResult({ score, xpEarned: awardedXp, timeSec })
    setDone(true)
  }

  function commitChoice(i: number) {
    if (answered) return
    setSelected(i)
    const correct = i === question.answerIndex
    setLastCorrect(correct)
    setAnswered(true)
    if (correct) setCorrectCount((c) => c + 1)
  }

  function toggleMulti(i: number) {
    if (answered) return
    setSelectedMulti((prev) => (prev.includes(i) ? prev.filter((v) => v !== i) : [...prev, i]))
  }

  function commitMulti() {
    if (answered || selectedMulti.length === 0) return
    const expected = [...(question.answerIndexes ?? [])].sort()
    const given = [...selectedMulti].sort()
    const correct = expected.length === given.length && expected.every((v, k) => v === given[k])
    setLastCorrect(correct)
    setAnswered(true)
    if (correct) setCorrectCount((c) => c + 1)
  }

  function commitText() {
    if (answered || !textValue.trim()) return
    const correct =
      textValue.trim().toLowerCase() === (question.answer ?? '').trim().toLowerCase()
    setLastCorrect(correct)
    setAnswered(true)
    if (correct) setCorrectCount((c) => c + 1)
  }

  function chooseOrder(i: number) {
    if (answered) return
    const next = [...orderChosen, i]
    setOrderChosen(next)
    if (next.length === (question.sequence?.length ?? 0)) {
      const correct = next.every((v, pos) => v === pos)
      setLastCorrect(correct)
      setAnswered(true)
      if (correct) setCorrectCount((c) => c + 1)
    }
  }

  function completeInteractive() {
    // match-concepts y memory: completarlos cuenta como acierto.
    setLastCorrect(true)
    setAnswered(true)
    setCorrectCount((c) => c + 1)
  }

  function next() {
    const nextCorrect = correctCount
    if (index + 1 >= total) {
      finish(nextCorrect)
      return
    }
    setIndex((i) => i + 1)
    setSelected(null)
    setSelectedMulti([])
    setTextValue('')
    setOrderChosen([])
    setAnswered(false)
    setLastCorrect(false)
  }

  if (todayCompleted && !done) {
    return (
      <ActivityResultScreen
        activity={activity}
        correctCount={todayCompleted.correctCount}
        total={todayCompleted.totalCount}
        score={todayCompleted.score}
        xpEarned={0}
        timeSec={todayCompleted.timeSec}
        onRetry={() => window.location.reload()}
        alreadyCompleted
      />
    )
  }

  if (done && result) {
    return (
      <ActivityResultScreen
        activity={activity}
        correctCount={correctCount}
        total={total}
        score={result.score}
        xpEarned={result.xpEarned}
        timeSec={result.timeSec}
        onRetry={() => window.location.reload()}
        newBadges={newBadges}
      />
    )
  }

  return (
    <main className="min-h-screen bg-background">
      {celebrate && (
        <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden" aria-live="polite">
          <div className="absolute left-1/2 top-1/3 -translate-x-1/2 rounded-2xl bg-background/95 px-6 py-4 text-center shadow-xl">
            <p className="font-display text-2xl font-extrabold text-primary">{'🎉 ¡Lo lograste!'}</p>
            <p className="mt-1 font-bold text-muted-foreground">+{activity.xpReward} XP</p>
          </div>
          {Array.from({ length: 32 }, (_, i) => (
            <span
              key={i}
              className="absolute top-0 h-3 w-2 animate-[confetti-fall_2.5s_ease-in_forwards] rounded-sm"
              style={{ left: `${(i * 31) % 100}%`, backgroundColor: ['#f97316', '#22c55e', '#3b82f6', '#eab308'][i % 4], animationDelay: `${(i % 8) * 80}ms` }}
            />
          ))}
        </div>
      )}
      {/* Barra superior con progreso */}
      <header className="sticky top-0 z-10 border-b border-border bg-background">
        <div className="mx-auto flex max-w-3xl items-center gap-4 px-4 py-4">
          <Link
            href="/materias"
            aria-label="Salir de la actividad"
            className="grid size-9 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X className="size-5" />
          </Link>
          <ProgressBar value={((index + (answered ? 1 : 0)) / total) * 100} className="h-4" />
          {isTimed ? (
            <span
              className={cn(
                'inline-flex shrink-0 items-center gap-1 rounded-full px-3 py-1 text-sm font-extrabold',
                timeLeft <= 10 ? 'bg-destructive/10 text-destructive' : 'bg-muted text-foreground',
              )}
            >
              <Timer className="size-4" />
              {timeLeft}s
            </span>
          ) : (
            <span className="shrink-0 text-sm font-bold text-muted-foreground">
              {index + 1}/{total}
            </span>
          )}
        </div>
      </header>

      <div className="mx-auto flex max-w-3xl flex-col px-4 pb-32 pt-8">
        {/* Render de la pregunta según su forma (así un mismo juego puede mezclar tipos) */}
        {kind === 'choice' && (
          <ChoiceQuestion
            question={question}
            selected={selected}
            selectedMulti={selectedMulti}
            answered={answered}
            onSelect={isMulti ? toggleMulti : commitChoice}
          />
        )}

        {kind === 'body' && (
          <BodyQuestion question={question} selected={selected} answered={answered} onSelect={commitChoice} />
        )}

        {kind === 'text' && (
          <CompleteWordQuestion
            question={question}
            value={textValue}
            answered={answered}
            isCorrect={lastCorrect}
            onChange={setTextValue}
          />
        )}

        {kind === 'order' && (
          <OrderQuestion
            question={question}
            chosen={orderChosen}
            answered={answered}
            isCorrect={lastCorrect}
            onChoose={chooseOrder}
            onReset={() => setOrderChosen([])}
          />
        )}

        {kind === 'match' && (
          <MatchQuestion question={question} answered={answered} onComplete={completeInteractive} />
        )}

        {kind === 'memory' && (
          <MemoryQuestion question={question} answered={answered} onComplete={completeInteractive} />
        )}
      </div>

      {/* Barra inferior de acción */}
      <footer
        className={cn(
          'fixed inset-x-0 bottom-0 border-t transition-colors',
          answered && lastCorrect && 'border-success/30 bg-success/10',
          answered && !lastCorrect && 'border-destructive/30 bg-destructive/10',
          !answered && 'border-border bg-background',
        )}
      >
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-4 px-4 py-4">
          <div className="min-h-6">
            {answered && (
              <p
                className={cn(
                  'font-display text-lg font-extrabold',
                  lastCorrect ? 'text-success' : 'text-destructive',
                )}
              >
                {lastCorrect ? '¡Correcto! 🎉' : '¡Casi! Sigue intentando 💪'}
              </p>
            )}
          </div>

          {/* Botón de acción contextual */}
          {(kind === 'text' || isMulti) && !answered ? (
            <button
              type="button"
              onClick={isMulti ? commitMulti : commitText}
              disabled={isMulti ? selectedMulti.length === 0 : !textValue.trim()}
              className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-extrabold text-primary-foreground disabled:opacity-50"
            >
              Comprobar
            </button>
          ) : answered ? (
            <button
              type="button"
              onClick={next}
              className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-8 font-extrabold text-primary-foreground"
            >
              {index + 1 >= total ? 'Finalizar' : 'Continuar'}
              <ArrowRight className="size-5" />
            </button>
          ) : (
            <span className="text-sm text-muted-foreground">
              {kind === 'match' || kind === 'memory'
                ? 'Completa el ejercicio'
                : kind === 'body'
                  ? 'Toca la parte del cuerpo'
                  : 'Elige tu respuesta'}
            </span>
          )}
        </div>
      </footer>
    </main>
  )
}
