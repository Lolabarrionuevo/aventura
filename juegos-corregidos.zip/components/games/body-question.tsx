'use client'

import { cn } from '@/lib/utils'
import type { Question } from '@/lib/adventure/types'
import { SpeakButton } from './speak-button'

type Part = 'head' | 'arm' | 'hand' | 'body' | 'leg' | 'foot'

const SKIN = '#F6C79B'
const SHIRT = '#3B82F6'
const SHORTS = '#1E3A8A'
const SHOES = '#E5533D'
const HAIR = '#6B3F1D'

/** Dibujo del cuerpo donde se toca la parte pedida. No marca nada hasta que se responde. */
export function BodyQuestion({
  question,
  selected,
  answered,
  onSelect,
}: {
  question: Question
  selected: number | null
  answered: boolean
  onSelect: (index: number) => void
}) {
  const parts = (question.options ?? []) as Part[]
  const correctPart = question.answerIndex !== undefined ? parts[question.answerIndex] : undefined
  const selectedPart = selected !== null ? parts[selected] : undefined

  function stroke(part: Part) {
    if (!answered) return { stroke: 'transparent', strokeWidth: 0 }
    if (part === correctPart) return { stroke: '#16a34a', strokeWidth: 6 }
    if (part === selectedPart) return { stroke: '#dc2626', strokeWidth: 6 }
    return { stroke: 'transparent', strokeWidth: 0 }
  }

  function group(part: Part, children: React.ReactNode) {
    return (
      <g
        role="button"
        tabIndex={answered ? -1 : 0}
        aria-label={answered ? part : 'Parte del cuerpo'}
        className={cn(!answered && 'cursor-pointer hover:opacity-80 focus:opacity-80 focus:outline-none')}
        onClick={() => !answered && onSelect(parts.indexOf(part))}
        onKeyDown={(e) => {
          if (!answered && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault()
            onSelect(parts.indexOf(part))
          }
        }}
        {...stroke(part)}
      >
        {children}
      </g>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-balance text-center font-display text-2xl font-extrabold text-foreground">
        {question.prompt}
      </h2>
      {question.speak && <SpeakButton text={question.speak} />}

      <svg viewBox="0 0 240 390" className="mx-auto h-[26rem] max-h-[60vh] w-auto rounded-3xl bg-muted p-2" role="group" aria-label="Dibujo de un niño">
        {/* Piernas */}
        {group('leg', (
          <>
            <rect x="84" y="276" width="32" height="82" rx="12" fill={SKIN} />
            <rect x="124" y="276" width="32" height="82" rx="12" fill={SKIN} />
          </>
        ))}
        {/* Pies */}
        {group('foot', (
          <>
            <rect x="72" y="350" width="50" height="26" rx="13" fill={SHOES} />
            <rect x="118" y="350" width="50" height="26" rx="13" fill={SHOES} />
          </>
        ))}
        {/* Brazos */}
        {group('arm', (
          <>
            <rect x="44" y="128" width="32" height="56" rx="15" fill={SHIRT} />
            <rect x="48" y="176" width="26" height="60" rx="12" fill={SKIN} />
            <rect x="164" y="128" width="32" height="56" rx="15" fill={SHIRT} />
            <rect x="166" y="176" width="26" height="60" rx="12" fill={SKIN} />
          </>
        ))}
        {/* Manos */}
        {group('hand', (
          <>
            <circle cx="61" cy="250" r="17" fill={SKIN} />
            <circle cx="179" cy="250" r="17" fill={SKIN} />
          </>
        ))}
        {/* Cuerpo: camiseta y short */}
        {group('body', (
          <>
            <rect x="74" y="124" width="92" height="116" rx="20" fill={SHIRT} />
            <rect x="78" y="226" width="84" height="56" rx="14" fill={SHORTS} />
          </>
        ))}
        {/* Cabeza */}
        {group('head', (
          <>
            <rect x="106" y="112" width="28" height="22" rx="8" fill={SKIN} />
            <circle cx="68" cy="72" r="11" fill={SKIN} />
            <circle cx="172" cy="72" r="11" fill={SKIN} />
            <circle cx="120" cy="68" r="52" fill={SKIN} />
            <path d="M66 76 C56 14 184 14 174 76 C166 58 148 50 120 50 C92 50 74 58 66 76 Z" fill={HAIR} />
            <circle cx="102" cy="74" r="6" fill="#33281E" />
            <circle cx="138" cy="74" r="6" fill="#33281E" />
            <circle cx="92" cy="90" r="7" fill="#F2A28C" opacity="0.6" />
            <circle cx="148" cy="90" r="7" fill="#F2A28C" opacity="0.6" />
            <path d="M104 94 Q120 110 136 94" stroke="#B5533C" strokeWidth="4" fill="none" strokeLinecap="round" />
          </>
        ))}
      </svg>
    </div>
  )
}
