'use client'

import { Check, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Question } from '@/lib/adventure/types'
import { SpeakButton } from './speak-button'

export function ChoiceQuestion({
  question,
  selected,
  selectedMulti = [],
  answered,
  onSelect,
}: {
  question: Question
  selected: number | null
  /** Opciones marcadas cuando la pregunta permite elegir varias. */
  selectedMulti?: number[]
  answered: boolean
  /** Con una sola respuesta responde; con varias marca o desmarca. */
  onSelect: (index: number) => void
}) {
  const multi = Array.isArray(question.answerIndexes)
  const correctSet = multi ? question.answerIndexes! : question.answerIndex !== undefined ? [question.answerIndex] : []
  const hasImageOptions = Array.isArray(question.optionImages) && question.optionImages.length > 0
  const stacked = question.optionLayout === 'stack'

  return (
    <div className="flex flex-col gap-5">
      {question.passage && (
        <div className="rounded-2xl border-2 border-border bg-card p-4 text-lg font-semibold leading-relaxed text-card-foreground">
          {question.passage.split('\n').map((line) => (
            <p key={line}>{line}</p>
          ))}
        </div>
      )}

      {question.image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={question.image}
          alt="Imagen de la pregunta"
          className="mx-auto max-h-56 w-auto max-w-full rounded-3xl bg-muted object-contain p-2"
        />
      )}

      <h2 className="text-balance text-center font-display text-2xl font-extrabold text-foreground">
        {question.prompt}
      </h2>

      {question.speak && <SpeakButton text={question.speak} />}

      {multi && !answered && (
        <p className="text-center text-sm font-bold text-muted-foreground">Puedes elegir más de una opción.</p>
      )}

      {hasImageOptions ? (
        <div
          className={cn(
            'grid gap-3',
            stacked ? 'mx-auto w-full max-w-md grid-cols-1' : (question.options?.length ?? 0) > 4 ? 'grid-cols-2 sm:grid-cols-3' : 'grid-cols-2',
          )}
        >
          {question.options?.map((label, i) => {
            const isCorrect = correctSet.includes(i)
            const isSelected = multi ? selectedMulti.includes(i) : i === selected
            return (
              <button
                key={`${label}-${i}`}
                type="button"
                disabled={answered}
                onClick={() => onSelect(i)}
                aria-label={answered ? label : `Opción ${i + 1}`}
                aria-pressed={multi ? isSelected : undefined}
                className={cn(
                  'relative flex flex-col items-center gap-2 rounded-2xl border-2 p-3 transition-all',
                  !answered && !isSelected && 'border-border bg-card hover:-translate-y-0.5 hover:border-primary/50',
                  !answered && isSelected && 'border-primary bg-primary/10',
                  answered && isCorrect && 'border-success bg-success/10',
                  answered && isSelected && !isCorrect && 'border-destructive bg-destructive/10',
                  answered && !isCorrect && !isSelected && 'border-border bg-card opacity-60',
                )}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={question.optionImages![i]}
                  alt=""
                  className={cn(
                    'w-full rounded-xl bg-white object-contain',
                    stacked ? 'h-28' : 'aspect-square',
                  )}
                />
                {answered && <span className="text-base font-extrabold text-foreground">{label}</span>}
                {answered && isCorrect && <Check className="absolute right-2 top-2 size-6 rounded-full bg-success p-1 text-white" />}
                {answered && isSelected && !isCorrect && (
                  <X className="absolute right-2 top-2 size-6 rounded-full bg-destructive p-1 text-white" />
                )}
              </button>
            )
          })}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {question.options?.map((option, i) => {
            const isCorrect = correctSet.includes(i)
            const isSelected = multi ? selectedMulti.includes(i) : i === selected
            return (
              <button
                key={option}
                type="button"
                disabled={answered}
                onClick={() => onSelect(i)}
                aria-pressed={multi ? isSelected : undefined}
                className={cn(
                  'flex items-center justify-between gap-2 rounded-2xl border-2 px-5 py-4 text-left text-lg font-bold transition-all',
                  !answered && !isSelected && 'border-border bg-card text-card-foreground hover:-translate-y-0.5 hover:border-primary/50',
                  !answered && isSelected && 'border-primary bg-primary/10 text-foreground',
                  answered && isCorrect && 'border-success bg-success/10 text-foreground',
                  answered && isSelected && !isCorrect && 'border-destructive bg-destructive/10 text-foreground',
                  answered && !isCorrect && !isSelected && 'border-border bg-card opacity-60',
                )}
              >
                {option}
                {answered && isCorrect && <Check className="size-5 shrink-0 text-success" />}
                {answered && isSelected && !isCorrect && <X className="size-5 shrink-0 text-destructive" />}
              </button>
            )
          })}
        </div>
      )}

      {/* La pista solo aparece DESPUÉS de responder, para no regalar la respuesta. */}
      {question.hint && answered && (
        <p className="text-center text-sm font-bold text-muted-foreground">💡 {question.hint}</p>
      )}
    </div>
  )
}
