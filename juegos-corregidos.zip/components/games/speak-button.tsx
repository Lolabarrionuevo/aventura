'use client'

import { Volume2 } from 'lucide-react'

/** Lee una palabra o frase en inglés con la voz del navegador. */
export function SpeakButton({ text, label = 'Escuchar' }: { text: string; label?: string }) {
  function speak() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'en-US'
    utterance.rate = 0.85
    window.speechSynthesis.speak(utterance)
  }

  return (
    <button
      type="button"
      onClick={speak}
      aria-label={label}
      className="mx-auto inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-extrabold text-primary transition-all hover:bg-primary/20"
    >
      <Volume2 className="size-5" />
      {label}
    </button>
  )
}
